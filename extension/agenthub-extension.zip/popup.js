import"./assets/modulepreload-polyfill-B5Qt9EMX.js";import{h as p}from"./assets/supabaseClient-vgDX0NvR.js";const l=document.getElementById("app"),e={isAuthenticated:!1,isSelecting:!1,isSaving:!1,fields:[]},c=async()=>(await chrome.storage.local.get(["ah_session"])).ah_session||null,d=async i=>{i?await chrome.storage.local.set({ah_session:i}):await chrome.storage.local.remove(["ah_session"])},o=async()=>{if(!await p())e.isAuthenticated=!1,e.error="Supabase not configured. Open Options and set SUPABASE_URL and SUPABASE_ANON_KEY.";else{const t=await c();e.isAuthenticated=!!t?.token&&!!t?.user?.id}l.innerHTML=`
    <div class="container">
      <header>
        <div class="brand">AgentHub Extractor</div>
        ${e.isAuthenticated?'<button id="logoutBtn" class="btn ghost">Logout</button>':""}
      </header>

      ${e.isAuthenticated?`
      <section class="card">
        <div class="row">
          <button id="selectBtn" class="btn secondary">${e.isSelecting?"Selecting…":"Start Selecting"}</button>
          <button id="saveBtn" class="btn primary" ${e.fields.length===0||e.isSaving?"disabled":""}>${e.isSaving?"Saving…":"Save and Sync to AgentHub"}</button>
        </div>
      </section>

      <section class="card">
        <h2>Selected Fields (${e.fields.length})</h2>
        <div class="list">
          ${e.fields.map(t=>`
            <div class="list-item">
              <div class="meta">
                <div class="label">${t.label}</div>
                <div class="hint">${t.xpath}</div>
              </div>
              <div class="text">${g(t.text).slice(0,240)}</div>
              <button data-id="${t.id}" class="btn xs ghost remove">Remove</button>
            </div>
          `).join("")}
        </div>
      </section>
      `:`
      <section class="card">
        <h2>Sign in</h2>
        <label>Email <input id="email" type="email" placeholder="you@company.com" /></label>
        <label>Password <input id="password" type="password" placeholder="••••••••" /></label>
        <button id="loginBtn" class="btn primary">Login</button>
        ${e.error?`<div class="error">${e.error}</div>`:""}
        <p class="hint" style="margin-top:8px;opacity:.8">If login fails immediately, set Supabase config in Options.</p>
        <div style="margin-top:8px">
          <a id="openOptions" class="btn ghost" href="#">Open Options</a>
        </div>
      </section>
      `}
    </div>
  `,e.isAuthenticated?(document.getElementById("logoutBtn")?.addEventListener("click",async()=>{await d(null),await o()}),document.getElementById("selectBtn")?.addEventListener("click",async()=>{e.isSelecting=!0,await o(),chrome.tabs.query({active:!0,currentWindow:!0},t=>{const s=t[0]?.id;s&&chrome.tabs.sendMessage(s,{type:"ah:startSelecting"})})}),document.getElementById("saveBtn")?.addEventListener("click",async()=>{e.isSaving=!0,await o();try{const t=await c(),s=t?.user?.id;if(!s)throw new Error("No user");const a={userId:s,createdAt:new Date().toISOString(),meta:{source:"chrome-extension"},fields:e.fields,autoLabels:!0},n=await fetch("http://localhost:3001/api/extension/extract",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t.token}`},body:JSON.stringify(a)}),r=await n.json();if(!n.ok||!r?.success)throw new Error(r?.error||"Upload failed");e.fields=[]}catch(t){console.error(t)}finally{e.isSaving=!1,await o()}}),l.querySelectorAll(".remove").forEach(t=>{t.addEventListener("click",async s=>{const a=s.currentTarget.getAttribute("data-id");a&&(e.fields=e.fields.filter(n=>n.id!==a),await o())})})):(document.getElementById("loginBtn")?.addEventListener("click",async()=>{const t=document.getElementById("email")?.value,s=document.getElementById("password")?.value;try{const a=await fetch("http://localhost:3001/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:t,password:s})}),n=await a.json();if(!a.ok||!n?.success)throw new Error(n?.error||"Login failed");const r={token:n.data.token,user:n.data.user};await d(r),e.error=void 0,await o()}catch(a){e.error=a?.message||"Login failed",await o()}}),document.getElementById("openOptions")?.addEventListener("click",t=>{t.preventDefault(),chrome.runtime.openOptionsPage()}))};chrome.runtime.onMessage.addListener(i=>{if(i?.type==="ah:selectionUpdate"){e.isSelecting=!1;const t=(i.payload||[]).map(s=>({id:crypto.randomUUID(),label:s.label||"Field",text:s.text,xpath:s.xpath}));e.fields=u(e.fields,t),o()}});const u=(i,t)=>{const s=new Map;for(const a of[...i,...t])s.set(a.xpath,a);return Array.from(s.values())},g=i=>i.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");o();
